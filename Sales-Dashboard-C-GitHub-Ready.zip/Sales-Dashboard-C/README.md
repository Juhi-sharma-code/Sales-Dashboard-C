# Sales Dashboard Using C

A console-based Sales Dashboard project developed in **C language** for an academic/portfolio project.

## Features

- Total Revenue
- Total Orders
- Average Order Value (AOV)
- Sales data table
- Date-wise revenue trend
- Top-selling product by revenue
- Region-wise sales comparison
- Menu-driven interface
- Basic input validation

## Technologies

- C
- Standard C Library
- GCC / Code::Blocks / Dev-C++ / any standard C compiler

## Project Structure

```text
Sales-Dashboard-C/
├── sales_dashboard.c
├── README.md
├── Project_Report.docx
├── sample_output.txt
└── screenshots/
    └── README.txt
```

## How to Run

### GCC

```bash
gcc sales_dashboard.c -o sales_dashboard
./sales_dashboard
```

### Windows

```bash
gcc sales_dashboard.c -o sales_dashboard.exe
sales_dashboard.exe
```

## Sample Dashboard

```text
============= SALES DASHBOARD =============
Total Revenue       : Rs. 1565000.00
Total Orders        : 105
Average Order Value : Rs. 14904.76
===========================================
```

## Concepts Used

- Structures
- Arrays
- Functions
- Loops
- Conditional statements
- String handling
- Formatted input/output

## College

**Sushila Devi Bansal College of Technology, Indore**

## Author

Name: __________________________  
Enrollment No.: __________________________  
Course: B.Tech – 3rd Semester  
Academic Session: 2026–27

## Future Enhancements

- User input for new sales records
- File handling
- Daily/weekly/monthly filters
- Category filters
- ASCII charts
- Database connectivity
- Graphical user interface
