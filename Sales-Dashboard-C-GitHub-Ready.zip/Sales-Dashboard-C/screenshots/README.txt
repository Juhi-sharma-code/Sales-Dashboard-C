Add screenshots of your program output in this folder before publishing the repository.
Recommended screenshot names:
- dashboard.png
- sales-data.png
- region-sales.png
