#include <stdio.h>
#include <string.h>

#define MAX_SALES 100

typedef struct {
    char date[15];
    char product[30];
    char category[30];
    char region[20];
    int orders;
    float revenue;
} Sale;

void showDashboard(const Sale sales[], int n);
void showSalesData(const Sale sales[], int n);
void showRevenueTrend(const Sale sales[], int n);
void showTopProduct(const Sale sales[], int n);
void showRegionSales(const Sale sales[], int n);

int main(void) {
    Sale sales[MAX_SALES] = {
        {"01-Sep-26", "Laptop",     "Electronics", "North", 5, 250000.0f},
        {"02-Sep-26", "Mobile",     "Electronics", "South", 8, 160000.0f},
        {"03-Sep-26", "Headphones", "Accessories", "East", 15, 45000.0f},
        {"04-Sep-26", "Laptop",     "Electronics", "West", 4, 200000.0f},
        {"05-Sep-26", "Mobile",     "Electronics", "North", 10, 200000.0f},
        {"06-Sep-26", "Keyboard",   "Accessories", "South", 12, 36000.0f},
        {"07-Sep-26", "Laptop",     "Electronics", "East", 6, 300000.0f},
        {"08-Sep-26", "Mouse",      "Accessories", "West", 20, 30000.0f},
        {"09-Sep-26", "Mobile",     "Electronics", "East", 7, 140000.0f},
        {"10-Sep-26", "Headphones", "Accessories", "North", 18, 54000.0f}
    };

    int n = 10;
    int choice;

    do {
        printf("\n=============================================\n");
        printf("           SALES DASHBOARD USING C\n");
        printf("=============================================\n");
        printf("1. View Dashboard\n");
        printf("2. View Sales Data\n");
        printf("3. Revenue Trend\n");
        printf("4. Top Selling Product\n");
        printf("5. Region-wise Sales\n");
        printf("6. Exit\n");
        printf("---------------------------------------------\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("\nInvalid input. Please enter a number.\n");
            while (getchar() != '\n') {}
            continue;
        }

        switch (choice) {
            case 1:
                showDashboard(sales, n);
                break;
            case 2:
                showSalesData(sales, n);
                break;
            case 3:
                showRevenueTrend(sales, n);
                break;
            case 4:
                showTopProduct(sales, n);
                break;
            case 5:
                showRegionSales(sales, n);
                break;
            case 6:
                printf("\nThank you for using Sales Dashboard!\n");
                break;
            default:
                printf("\nInvalid choice! Please try again.\n");
        }
    } while (choice != 6);

    return 0;
}

void showDashboard(const Sale sales[], int n) {
    int i, totalOrders = 0;
    float totalRevenue = 0.0f;

    for (i = 0; i < n; i++) {
        totalOrders += sales[i].orders;
        totalRevenue += sales[i].revenue;
    }

    printf("\n============= SALES DASHBOARD =============\n");
    printf("Total Revenue       : Rs. %.2f\n", totalRevenue);
    printf("Total Orders        : %d\n", totalOrders);
    printf("Average Order Value : Rs. %.2f\n",
           totalOrders ? totalRevenue / totalOrders : 0.0f);
    printf("===========================================\n");
}

void showSalesData(const Sale sales[], int n) {
    int i;

    printf("\n================ SALES DATA ================\n");
    printf("%-12s %-15s %-12s %-10s %-8s %-12s\n",
           "Date", "Product", "Category", "Region", "Orders", "Revenue");
    printf("---------------------------------------------------------------\n");

    for (i = 0; i < n; i++) {
        printf("%-12s %-15s %-12s %-10s %-8d Rs.%-10.2f\n",
               sales[i].date, sales[i].product, sales[i].category,
               sales[i].region, sales[i].orders, sales[i].revenue);
    }
}

void showRevenueTrend(const Sale sales[], int n) {
    int i;

    printf("\n=============== REVENUE TREND ===============\n");
    for (i = 0; i < n; i++) {
        printf("%-12s : Rs. %.2f\n", sales[i].date, sales[i].revenue);
    }
}

void showTopProduct(const Sale sales[], int n) {
    int i, j;
    float maxRevenue = -1.0f;
    char topProduct[30] = "";

    for (i = 0; i < n; i++) {
        float productRevenue = 0.0f;

        for (j = 0; j < n; j++) {
            if (strcmp(sales[i].product, sales[j].product) == 0) {
                productRevenue += sales[j].revenue;
            }
        }

        if (productRevenue > maxRevenue) {
            maxRevenue = productRevenue;
            strcpy(topProduct, sales[i].product);
        }
    }

    printf("\n=========== TOP SELLING PRODUCT ===========\n");
    printf("Product : %s\n", topProduct);
    printf("Revenue : Rs. %.2f\n", maxRevenue);
}

void showRegionSales(const Sale sales[], int n) {
    int i;
    float north = 0.0f, south = 0.0f, east = 0.0f, west = 0.0f;

    for (i = 0; i < n; i++) {
        if (strcmp(sales[i].region, "North") == 0)
            north += sales[i].revenue;
        else if (strcmp(sales[i].region, "South") == 0)
            south += sales[i].revenue;
        else if (strcmp(sales[i].region, "East") == 0)
            east += sales[i].revenue;
        else if (strcmp(sales[i].region, "West") == 0)
            west += sales[i].revenue;
    }

    printf("\n============= REGION-WISE SALES =============\n");
    printf("North : Rs. %.2f\n", north);
    printf("South : Rs. %.2f\n", south);
    printf("East  : Rs. %.2f\n", east);
    printf("West  : Rs. %.2f\n", west);
}
